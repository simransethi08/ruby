#!/usr/bin/ruby

require 'pg'

begin

	con=PG.connect :dbname => 'testdb', :user =>'simran', :password =>'root'
	stmt="SELECT $1::int AS a,$2::int AS b,$3::int AS c"
	rs=con.exec_params(stmt, [1,2,3])

	puts rs.values

rescue PG::Error =>e
	puts e.message
ensure

	con.close if con
	rs.clear if rs
end
