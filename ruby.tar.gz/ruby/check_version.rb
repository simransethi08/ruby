#!/usr/bin/ruby


require 'pg'

begin

	con = PG.connect :dbname => 'testdb', :user =>'simran', :password =>'root'
	
	rs=con.exec 'SELECT VERSION()'
	puts rs.getvalue 0,0

rescue PG::ERROR =>e
	puts e.message

ensure

	con.close if con
end


