#!/usr/bin/ruby

require 'pg'

if ARGV.length != 1 then
	puts "Usage: prepared_statement.rb rowId"
	exit
end

rowId=ARGV[0]

begin

	con=PG.connect :dbname =>'testdb', :user =>'simran', :password =>'root'
	
	con.prepare 'stmt',"SELECT * FROM Cars WHERE Id=$1"
	rs=con.exec_prepared 'stmt', [rowId]

	puts rs.values

rescue PG::Error =>e

	puts e.message

ensure

	con.close if con
	rs.clear if rs
end


