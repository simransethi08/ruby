!#/usr/home/bin/home

require 'pg'

begin

	con=PG.connect :dbname =>'testdb',:user =>'simran',:password =>'root'
	rs=con.exec 'SELECT * FROM Cars'

	rs.each do |row|
		puts "%s %s %s" %[row['id'], row['name'], row['price'] ]
	end
rescue PG::error =>e
	puts e.message
ensure
	rs.clear if rs
	con.close if con
end	
