#!usr/bin/ruby

def lawful_good   
  paladin = Proc.new { return }   
  chaotic_evil(paladin)   
  puts “Lawful good!” 
end
def chaotic_evil(recruit)   
  recruit.call   
  puts “Chaotic evil!” 
end

