#!/usr/bin/ruby

labamba = lambda { return } 
labamba.call 

proctor = Proc.new { return } 
proctor.call 


