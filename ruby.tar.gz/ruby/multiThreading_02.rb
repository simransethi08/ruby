!#/usr/bin/ruby

require 'thread'
mutex=Mutex.new

cv=ConditionVariable.new

a=Thread.new {
	mutex.synchronize{
	puts "A: I have critical section but wait for CV"
	cv.wait(mutex)
	puts "A: I have critical section"

}

}

puts "Laters baby"

b=Thread.new {
	mutex.synchronize{
	puts "B: I am in critical section and won't release the lock"
	cv.signal
	puts "I am giving my section to A"
}

}

a.join
b.join
