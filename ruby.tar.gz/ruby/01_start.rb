#!/usr/bin/ruby

puts "Enter your name"
name=gets
puts "Enter your age"
age=gets

puts "your name is #{name}\n and age is #{age}"
