#!/usr/bin/ruby

def first(arg = nil)
  yield('first') if block_given?
end
def second(arg = nil)
  yield('second') if block_given?
end
# This block will be passed to first

first second { |method_name| puts method_name }
first second do |method_name|
  puts method_name
end
# => first
# This block will be passed to second

# => second

