#!/usr/bin/ruby

require 'pg'

begin

    con = PG.connect :dbname => 'testdb', :user => 'simran', :password =>'root'
    
    con.transaction do |con|
        
        con.exec "UPDATE Cars SET Price=23700 WHERE Id=8"
        con.exec "INSERT INTO Car VALUES(9,'Mazda',27770)"
    
    end
    
rescue PG::Error => e

    puts e.message 
    
ensure

    con.close if con
    
end
