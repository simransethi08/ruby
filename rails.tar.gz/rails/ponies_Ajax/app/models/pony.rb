class Pony < ActiveRecord::Base
end
