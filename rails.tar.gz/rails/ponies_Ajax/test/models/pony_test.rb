require 'test_helper'

class PonyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
