Debbie:
 [![Build Status](https://debbie.postgis.net/buildStatus/icon?job=PostGIS_2.2)]
 (https://debbie.postgis.net/view/PostGIS/job/PostGIS_2.2/)
Winnie:
 [![Build Status](https://debbie.postgis.net:444/buildStatus/icon?job=PostGIS_2.2)]
 (https://debbie.postgis.net:444/view/PostGIS/job/PostGIS_2.2/)
Dronie:
 [![Build Status](https://drone.osgeo.kbt.io/api/badges/postgis/postgis/status.svg?branch=svn-2.2)]
 (https://drone.osgeo.kbt.io/postgis/postgis?branch=svn-2.2)
Travis:
 [![Build Status](https://secure.travis-ci.org/postgis/postgis.png?branch=svn-2.2)]
 (http://travis-ci.org/postgis/postgis)
GitLab-CI:
 [![Gitlab-CI](https://gitlab.com/postgis/postgis/badges/svn-2.2/build.svg)]
 (https://gitlab.com/postgis/postgis/commits/svn-2.2)

This file is here to play nicely with modern code repository facilities.
Actual readme is [here](README.postgis).

## Official code repository, issue tracker and wiki:
https://trac.osgeo.org/postgis/

## Official source tarball releases
http://postgis.net/source

If you would like to contribute to this project, please refer to our
[contributing guidelines](CONTRIBUTING.md).

## Project Home Page and Manuals
Project homepage: http://postgis.net/
PostGIS Manuals: http://postgis.net/documentation
