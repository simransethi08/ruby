module.exports = 'module b';
