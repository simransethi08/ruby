module.exports = 'module a';
